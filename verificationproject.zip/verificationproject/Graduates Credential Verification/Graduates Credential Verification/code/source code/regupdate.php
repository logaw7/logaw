<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:yusuf.php");
		   }
		   else
		   {
		   ?><html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Registerar page
</title>
</head>
<body id="contianer">
<div id="bod">
<?php
		include "registerarheader.php";
		?>
				<div id="leftsh">
<?php
		include "registerarLeft.php";
		?>
<div id="spaceesh">
<div id="aformsh">
<h3>Display Graduate Information Form:</h3>
<form action="regupdatepro.php" method="post">
<table  border="1">
<tr bgcolor="#85A157"><th>ID:</th><th>First_Name</th><th>Midle_Name</th><th>Last_Name</th><th>Gpa</th><th>Year</th><th>Qualification</th><th>Gender</th><th>Department</th><th>Photo</th><th>Edit</th><th>Delete</th></tr>
<?php
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select * from student";
$r=mysql_query($q,$con);
 while($row = mysql_fetch_array($r))
{
$Id=$row['ID'];
$fn=$row['Frist_Name'];
$mn=$row['Midle_Name'];
$ln=$row['Last_Name'];
$cg=$row['Cumulative_Gpa'];
$yog=$row['Year_of_Graduation'];
$q=$row['Qualification'];
$g=$row['Gender'];
$d=$row['Department'];
$p=$row['Photo'];
?>
<tr bgcolor="#BADFE8" ><td><strong><?php echo $Id;?></strong></td><td><strong><?php echo $fn;?></strong></td><td><strong><?php echo $mn;?></strong></td><td><strong><?php echo $ln;?></strong></td><td><strong><?php echo $cg;?></strong></td><td><strong><?php echo $yog;?></strong></td><td><strong><?php echo $q;?></strong></td><td><strong><?php echo $g;?></strong></td><td><strong><?php echo $d;?></strong></td><td><strong><img src="imagepro.php?ID=<?php echo $row['ID']?>" width="100" height="100"></td><td><strong><a href="regupdatepro.php?ID=<?php echo $Id;?>">Edit</a></strong></td><td><strong><a href="redeletestudent.php?ID=<?php echo $Id;?>">Delete</a></strong></strong></tr>
                    <?php
}
?>
</table>
</div>
</form>
</div>
	</div>
<?php
		include "yfoot.php";
		?>
</div>

</body>
</html>
<?php
}
?>
