<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:yusuf.php");
		   }
		   else
		   {
		   ?>
<html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Registerar page
</title>
</head>
<body id="contianer">
<div id="body">
<?php
		include "registerarheader.php";
		?>
		<div id="left">
<?php
		include "registerarLeft.php";
		?>
		</div>
<div id="spacee">
<br>
<img src="iterfaceimage/regrr.jpg" width="700" height="300"/>
<div id="adminb"><p><strong><font color="green" size="4">Welcome to online graduate credentials verfication system</font> </strong></p></div></div>

<?php
		include "yfoot.php";
		?>
</div>
</body>
</html>
<?php
}
?>