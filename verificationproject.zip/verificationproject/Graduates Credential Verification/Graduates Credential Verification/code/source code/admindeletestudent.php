<html>
<head>
<title>Delete Student</title>
</head>
<body>
<?php
$Id=$_GET['ID'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
	$sql = "delete from student where student.ID='".$Id."'";
	mysql_query ($sql,$con);
	mysql_close ($con);
	echo '<script type="text/javascript">alert("Student Updated Succesfully");window.location=\'adminUpdate.php\';</script>';

?>
</body>
</html>
