<html>
<head>
<title>AU GCVS</title>
</head>
<body>
<?php 
session_start();
$gid=$_POST['Gid'];
$Cphone=$_POST['cphone'];
$Cname=$_POST['cname'];
$Cemail=$_POST['cemail'];
$Ccountry=$_POST['ccountry'];
$Ccity=$_POST['ccity'];
$Date=$_POST['date'];
$Rfv=$_POST['rov'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "INSERT INTO company (ID,Company_Phone,Company_Name,Company_Email,Company_Country,Company_City,Date,Reason_of_Verification) VALUES (
'$gid','$Cphone','$Cname','$Cemail','$Ccountry','$Ccity','$Date','$Rfv')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
die(header("location:rf.php"));
mysql_close($con);

?>
</body>
</html>
