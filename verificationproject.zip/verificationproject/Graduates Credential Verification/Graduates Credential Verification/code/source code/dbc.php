

<html>
    <head>
    <title>Untitled Document</title>
    </head>
    <body>
    <?php
    // Establish Connection with Database
     $severname ="localhost";
     $username ="root";
     $passwor =" ";
    
    $con = mysqli_connect("$severname","$username","$password");
   if(!$con){
       die("connection faile".mysqli_connect_error());
   }
    ?>
    
    </body>
    </html>
    