 <div id="yuu"><ul>
 <br>
			<li><a href="AdminPage.php">Home</a></li>
                        <li><a href="InsertAndupdate.php">Insert graduate data</a></li>
                        <li><a href="adminUpdate.php">Display graduate data</a></li>
						<li><a href="adminsearchrepdel.php"> Report Generated</a></li>
							<li><a href="admindisplayuser.php">Display Account</a></li>
							<li><a href="UserAccount.php">Change Password</a></li>
							<li><a href="admindeletecompany.php">Display Company</a></li>
							<li><a href="admindisplayemploye.php">Display Employe</a></li>
							<li><a href="admindeleteapprovedreq.php">Approved Request</a></li>
							<li><a href="admindeleteverifiedreq.php">Verified Employe</a></li>
        </ul>	
     </div>