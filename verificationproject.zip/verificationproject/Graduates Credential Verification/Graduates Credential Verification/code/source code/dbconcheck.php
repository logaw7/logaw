
<html>
<head>
<title>Untitled Document</title>
</head>
<body>
<?php
// Establish Connection with Database
 $severname ="localhost";
 $username ="root";
 $password =" ";

$con = mysqli_connect("$severname","$username","$password");
//ssmysql_select_db('gcvs_db',$con);
$result=mysql_query("SELECT *FROM admin WHERE username='tesfish'");
$row=mysql_fetch_array($result);
echo $row['Admin_Id'];
// Close the connection
mysql_close($con);
?>

</body>
</html>
