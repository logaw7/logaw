<html>
<head>
<title> Home Page</title>
<link href="good.css" rel="stylesheet" type="text/css" />
</head>
<body id="contianer">
<div id="bod">
<div>
<?php
		include "yheader.php";
		?>
</div>                    
<div id="left">
<?php
		include "yleft.php";
		?>	
</div>
<div id="cent">
<div id="img">
<img src="iterfaceimage/gr.jpg" width="514" height="500"/>
</div>
<img src="iterfaceimage/wel8.gif" width="514" height="207"/>
</div>
<div id="righ">
<?php
		include "yright.php";
		?>
		<?php 
if (isset($_POST['Login']))
			
			{
session_start();
$UserName=$_POST['uname'];
$Password=$_POST['pword'];
$UserType=$_POST['selectop'];
if($UserType==="--select one--")
{
?>
<div class="alert alert-error">
			  	 Please select your account type
				 and try again!!!
				</div>
<?php 
}
else
{
if($UserType==="Administrator")
{
$con = mysqli_connect("localhost","root") or die(mysqli_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysqli_query($sql,$con);
$records = mysqli_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select ur account type
				 and try again!!!
				</div>

<?php 
}
else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:AdminPage.php");
} 
mysql_close($con);
}
else if($UserType==="Registerar")
{
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "select * from user where username='".$UserName."' and password='".$Password."' and  User_type='".$UserType."'";
$result = mysql_query($sql,$con);
$records = mysql_num_rows($result);
$row = mysql_fetch_array($result);
if ($records==0)
{
?>
<div class="alert alert-error">
			  	 Please check your User Name,Password and select ur account type
				 and try again!!!
				</div>

<?php 
}
else
{
session_start();
$_SESSION['username']=$row['username'];
header("location:RegisterarPage.php");
} 
mysql_close($con);
}
}
}
?>

</div>
<?php
		include "yfoot.php";
		?>
</div>
</body>
</html>
