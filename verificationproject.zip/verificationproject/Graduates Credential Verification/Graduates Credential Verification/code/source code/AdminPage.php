<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:yusuf.php");
		   }
		   else
		   {
		   ?>
<html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Adminstrator page
</title>
</head>
<body id="contianer">
<div id="body">
<?php
		include "adminheader.php";
		?>
				<div id="left">
<?php
		include "adminleft.php";
		?>
		</div>
<div id="spacee">
<br>
<font color="green" size="10"><i>your admin of the system</i></font>
<img src="iterfaceimage/adminn.jpg" width="700" height="300"/>
<div id="adminb">
<p>
<font color="green" size="4">
Welcome to online graduate credentials 
verfication system you are admin of the system </font></p></div></div>
<?php
		include "yfoot.php";
		?>

</div>
</body>
</html>
<?php
}
?>