<?php
 $gid=$_GET['ID'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select Photo,Photo_type from student WHERE ID='$gid'";
$r=mysql_query($q,$con);
if($r)
{
 $row= mysql_fetch_array($r);
 $type="content-type:".$row['Photo_type'];
 header($type);
echo $row['Photo'];
}
else
{
 echo mysql_error();
 }
?>