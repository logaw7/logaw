<div id="yuu"><ul>
 <br>
			<li><a href="RegisterarPage.php">Home</a></li>
                        <li><a href="insertregister.php">Insert graduate data</a></li>
                        <li><a href="regupdate.php">Display graduate data</a></li>
							<li><a href="sendmessearch.php">Generate report</a></li>
        </ul>	
     </div>