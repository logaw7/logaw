<div id="mheader">
<img src="iterfaceimage/logoaaa.gif" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="AdminPage.php">Home</a></li>
			<li><a href="#">Manage Graduate Informtion</a>
				<ul>
			<li> <a href="InsertAndupdate.php">Insert Graduate Informtion<br></a></li>
	<li><a href="adminUpdate.php">Dispaly Graduate Informtion<br></li></a>
				<li><a href="adminsearchrepdel.php">Dispaly Report Generated<br></a></li>
			</ul>
			</li>&nbsp;&nbsp;
				<li><a href="#">Create and Manage Account</a>&nbsp;&nbsp;
						<ul>
				<li> <a href="admindisplayuser.php">Display Account<br></a></li>
				<li> <a href="UserAccount.php">Change Password<br></a></li>
				</ul>
				</li>
				<li><a href="#">Display</a>&nbsp;&nbsp;
								<ul>
				<li> <a href="admindeletecompany.php">Request Company<br></a></li>
				<li> <a href="admindisplayemploye.php">Request Employe<br></a></li>
				<li> <a href="admindeleteapprovedreq.php">Approved Request<br></a></li>
				<li> <a href="admindeleteverifiedreq.php">Verified Employe Informtion<br></a></li>
				</ul></li>

    <li><a href="Logout.php">Log out</a></li>&nbsp;&nbsp;</ul></div>
 </hgroup>
</header>