<div id="mheader">
<img src="iterfaceimage/logoaaa.gif" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="yusuf.php">Home</a></li>&nbsp;&nbsp;
			<li><a href="#">External User</a> 
			<ul>
			<li> <a href="#">Request Credentials Verification<br></a>
			<ul>
	<li><a href="rf.php">Register Company<br></li></a>
				<li><a href="employeform.php">Register Employe<br></li></a>
			</ul></li>
			<li><a href="responsepage.php">View Response</a></li>
		</ul>
			</li>&nbsp;&nbsp;
			&nbsp;&nbsp;
                        <li><a href="aboutus.php">About Us</a></li>&nbsp;&nbsp;
				<li><a href="help.php">Help</a></li></ul></div>
 </hgroup>
</header>   