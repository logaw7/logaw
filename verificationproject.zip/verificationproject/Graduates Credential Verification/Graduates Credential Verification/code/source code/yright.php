<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<form name="forma" method="POST" id ="form" align="center">
 &nbsp;&nbsp;&nbsp;&nbsp;<table border=0 cellpadding=10px cellspacing=10px width=150px height=300px >
  <tr><td bgcolor="#bb9955">&nbsp;&nbsp;</td></tr>
  <tr><td>User Name:</td></tr>
<tr><td><span id="sprytextfield1">
              <label> <input type="text"  name="uname" class="user_name_hover" id="span9001" placeholder="User Name" size="30" ></label><span class="textfieldRequiredMsg"><br/><b>User name required</b></span></span></td></tr><br>
<tr><td>Password:</td></tr><br>
<tr><td><span id="sprytextfield2">
              <label> <input type="password"  name="pword" class="user_name_hover" id="span9001" placeholder="Password" size="30" >     </label><span class="textfieldRequiredMsg"><br/><b>Password required</b></span></span></td></tr>
<tr><td>Role: </td></tr>
 <tr><td><select name="selectop" id="span9001" >
<option>--select one--</option>
<option>Administrator</option>
<option>Registerar</option>
 </select></td></tr>
 <tr><td> </td></tr>
<tr><td> </td></tr>
<tr><td> </td></tr>
 <tr><td> </td></tr>
<tr><td>&nbsp;&nbsp; <button class="btn btn-primary" name="Login" ><i class="icon-ok-sign icon-large" ></i>&nbsp;Login</button>&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary" name="cler"><i class="icon-remove-sign icon-large" type="reset"></i>&nbsp;Clear</button> 
</td></tr>
					 <tr><td> <img src="iterfaceimage/key.jpg" width="150" height="150"></td> </tr>
					    <tr><td bgcolor="#bb9955">&nbsp;&nbsp;</td></tr>
					  </table>
</form>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>