<html>
<head>
<title>AU GCVS</title>
</head>
<body>
<?php 
session_start();
$eid=$_GET['ID'];
$rer=$_POST['rer'];
$ra=$_POST['regA'];
if ($ra=="--select one--")
{
echo '<script type="text/javascript">alert("Please select approval option");window.location=\'approveserreq2.php\';</script>';
exit();
}
else
{
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "INSERT INTO request_approval (Employe_ID,Registerar_Remark,Approval) VALUES ('$eid','$rer','$ra')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo '<script type="text/javascript">alert("Remark added success");window.location=\'approveserreq2.php\';</script>';
mysql_close($con);
}
?>
</body>
</html>
