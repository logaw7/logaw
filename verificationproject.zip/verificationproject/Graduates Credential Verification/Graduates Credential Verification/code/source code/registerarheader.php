<div id="mheader">
<img src="iterfaceimage/logoaaa.gif" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="RegisterarPage.php">Home</a></li>
			<li><a href="#">Manage Graduate Informtion</a>
				<ul>
	<li> <a href="insertregister.php">Insert Graduate Information<br></a></li>
	<li><a href="regupdate.php">Display Graduate Information<br></li></a>
			</ul>
			</li>
				<li><a href="approveserreq2.php">Approve Request</a></li>
    <li><a href="verifygraduateInfo.php">Verify</a></li>
			<li><a href="sendmessearch.php">Generate<br>Report</a>
			</li>
			
            <li><a href="logout.php">Log out</a></li>
		    </ul>
			</div>
 </hgroup>
</header>
