 <div id="yu"><ul>
 <br>
			<li><a href="bayisa.php">Home</a></li>
                        <li><a href="rf.php">Register Company</a></li>
                        <li><a href="employeform.php">Register Employe</a></li>
							<li><a href="responsepage.php">View Response</a></li>
						<li><a href="aboutus.php">About Us</a></li>
							<li><a href="help.php">Help</a></li>
        </ul>	
     </div>