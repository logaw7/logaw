<html><head>
<link href="good.css" rel="stylesheet" type="text/css"/>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript">
<!--
function validationForm() {
var gfn=document.forma.Gfname.value
var id=document.forma.Gid.value
var gmn=document.forma.Gmname.value
var gln=document.forma.Glname.value
 if (gfn=="")
{
window.alert("Graduate first name can not left blank");
return false;
}
else if (isNaN(gfn)==false)
{
window.alert("Graduate first name can not be number");
return false;
}
else if (gmn=="")
{
window.alert("Graduate Midle name can not left blank");
return false;
}
else if (isNaN(gmn)==false)
{
window.alert("Graduate Midle name can not be number");
return false;
}
else if (gln=="")
{
window.alert("Graduate Last name can not left blank");
return false;
}
else if (isNaN(gln)==false)
{
window.alert("Graduate Last name can not be number");
return false;
}
}
//>
</script>
</head>
<body id="contianer">
<div id="bod">
<div>
<?php
		include "yheader.php";
		?>
</div>                    
<div id="left">
<?php
		include "yleft.php";
		?></div>
		<div id="spacee">
		<div id="p">
		<img src="iterfaceimage/req.jpg" width="370" height="300"/>
<p align="center"><strong><font size="6" color="blue"><i>Welcome to<br> Madda Walabu University<br> Online Graduates Vredentials<br> Verification Systems</font><br><br><font size="4" color="blue"> Before filling these  information be  <br><br>sure credentials verification <br><br>requested &nbsp;</font><a href="rf.php"><font color="green">COMPANY</font></a></strong></p></div>
<div id="rf">
<h2>Response View Form:</h2>
<form  method="post" enctype="multipart/form-data" name="forma">
<table cellspacing="15" cellpadding="10">
<tr><td>Graduate_ID:</td><td><span id="sprytextfield1">
              <label><input type="text" name="Gid" id="span9001" placeholder="Stud ID_No" size="30" ></label><span class="textfieldRequiredMsg"><br/><b>Graduate ID required</b></span></span></td></tr><!--
<tr><td>First Name:</td><td><span id="sprytextfield2">
              <label><input type="text" name="Gfname" id="span9001" placeholder="Frist Name" size="30" ></label><span class="textfieldRequiredMsg"><br/><b>Frist Name required</b></span></span>
</td></tr>
<tr><td>Middle Name:</td><td><span id="sprytextfield3">
              <label><input type="text" name="Gmname" id="span9001" placeholder="Middle Name" size="30" ></label><span class="textfieldRequiredMsg"><br/><b>Middle Name required</b></span></span>
</td></tr>
<tr><td>Last Name:</td><td><span id="sprytextfield4">
              <label><input type="text" name="Glname" id="span9001" placeholder="Last Name" size="30" ></label><span class="textfieldRequiredMsg"><br/><b>Last Name required</b></span></span>
</td></tr>--></table>
<button class="btn btn-primary" name="gsub" onClick="validationForm()">&nbsp;CHECK RESULT</button>
<button type="reset" class="btn btn-primary"> CLEAR</button>
</form>
<?php 
if (isset($_POST['gsub']))
			
			{
$gid=$_POST['Gid'];
//$gfname=$_POST['Gfname'];
//$gmname=$_POST['Gmname'];
//$glname=$_POST['Glname'];
if (($gid==""))
{
die(header("location:responsepage.php"));
}
else
{
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select * from report where ID='$gid'";// and Frist_Name='$gfname' and Midle_Name='$gmname' and Last_Name='$glname'";
$r=mysql_query($q,$con);
if(mysql_num_rows($r)==0)
 {
$qq = "select * from company where ID='$gid'";
$rr=mysql_query($qq,$con);
$qqa = "select * from request_approval where Employe_ID='$gid'";
$a=mysql_query($qqa,$con);
$qqiv = "select * from info_verification where ID='$gid'";
$v=mysql_query($qqiv,$con);
if(mysql_num_rows($rr)==0){
?>
<div class="alert alert-error"><marquee style="background-color:#000000" direction="up">
			<h3 align="center">Verification is not requested or the This Student is not Graduate of Madda Walabu UNIVERSITY!!!</marquee></h3>
				</div>

<?php 
}
else if((mysql_num_rows($a)==0)&&(mysql_num_rows($v)==0)){
?>
<div class="alert alert-error">
			wait until the request is verified!!!
				</div>

<?php 
}
else 
{
while(($rowa= mysql_fetch_array($v))||($row= mysql_fetch_array($a)))
{
if(($rowa['Verification']=="Unverified")||($row['Approval']=="Disproved"))
{
?>
<div class="alert alert-error"><marquee direction="up">
			The student is not Graduate of Madda Walabu University!!!
				</marquee></div>

<?php 
}
else 
{
?>
<div class="alert alert-error">
Wait Until Report is Generated!!!
				</div>

<?php 
}
}
 }
 }
 else
 {
 while($row = mysql_fetch_array($r))
{
$Id=$row['ID'];
 ?>
<div class="alertr alert-error">Congratulations your request is verified successfully<br>
<a href="responsepageprocess.php?ID=<?php echo $Id;?>"><b><font color="red">Click here</font></b></a> to view!!!
				</div>

<?php
 mysql_close($con); 
 }
 }
 }
 }
 ?>
</div>
</div>
<?php
		include "yfoot.php";
		?>
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
//-->
</script>
</body>
</html>