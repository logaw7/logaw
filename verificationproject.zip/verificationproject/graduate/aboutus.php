
<html>
<head>
<title> Home Page</title>
<link href="good.css" rel="stylesheet" type="text/css" />
<style type="text/css">
    h1{
        color:#CC33AA;
	font-size:20px;
	margin: 20px 0px 20px 0px;
    }
	h2{
        color:#1705fe#CC33AA;
	font-size:14px;
	margin: 20px 0px 20px 0px;
    }
</style>
</head>
<body id="contianer">
<div id="bod">
<div>
<?php
		include "yheader.php";
		?>
</div>                    
<div id="left">
<?php
		include "yleft.php";
		?>	
</div>
<div id="spacee">
<div id="login" align="right"><h2>Would you want to <a href="bayisa.php"><font color="blue">LOGIN</font></a></h2></div>
<div align="left"> <img style="margin:10px 1px 1px 1px;float:left;" height="70%" width="30%" src="iterfaceimage/detail.png" alt="GCVS"/></div>
<h1 align="center">Welcome to Madda Walabu University Online Graduate Credentials Verification Systems</h1>
<hr/>
 <h2 align="justify"><font size="3"> Madda Walabu University established at 1999. At  present, the University runs Under-graduate Programs and Post Graduate program. In the  coming year Madda Walabu University works hard to achieve the universities vision of becoming one of the most prestigious universities in the country excelling in academic,research  and community service giving its utmost attention to quality education. </font></h2><hr/>
        <h2 align="justify">
To expand new constriction  is start before a years ago. The buildings are consists Office, Dormitory, classroom,  and Library.</h2><hr/><h3>Contact Address:</h3>
              <div>Madda Walabu University<br />
              <dl>Tell</dl>
			  <dd>+251226610529</dd>
			  <dd>+251226653091</dd>
			  </dl>
             <dl>Fax</dl>
			 <dd>+251226652519</dd>
			 </dl>
			<dl>P.O.Box</dl>
			<dd>247</dd>
			</dl>
			<dl>Website:</dl>
			<dd><a href="www.mwu.edu.et">www.mwu.edu.et</a></dd>
			<hr>
			</dl></div>
        </h2>
</div>
<?php
		include "yfoot.php";
		?>
</div>
</body>
</html>
