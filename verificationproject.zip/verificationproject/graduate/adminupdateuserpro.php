<html>
<head>
<title>MWU GCVS</title>
</head>
<body>
<?php 
$gid=$_GET['ID'];
$gfname=$_POST['Gfname'];
$gmname=$_POST['Gmname'];
$glname=$_POST['Glname'];
$yog=$_POST['Gpa'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "UPDATE user SET Name='".$gfname."',username='".$gmname."',Password='".$glname."',email='".$yog."' WHERE user.User_type='".$gid."'";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
mysql_close($con);
echo '<script type="text/javascript">alert("User Updated Succesfully");window.location=\'admindisplayuser.php\';</script>';
?>
</body>
</html>