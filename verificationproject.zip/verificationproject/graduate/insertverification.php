<html>
<head>
<title>MWU GCVS</title>
</head>
<body>
<?php 
session_start();
$eid=$_GET['ID'];
$rea=$_POST['regA'];
if ($rea=="--select one--")
{
echo '<script type="text/javascript">alert("please select verification option");window.location=\'verifygraduateInfo.php\';</script>';
exit();
}
else
{
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$sql = "INSERT INTO info_verification (ID,Verification) VALUES ('$eid','$rea')";
if(!mysql_query($sql,$con))
{
die('Error:'.mysql_error());
}
echo '<script type="text/javascript">alert("Verification added success");window.location=\'verifygraduateInfo.php\';</script>';
mysql_close($con);
}
?>
</body>
</html>
