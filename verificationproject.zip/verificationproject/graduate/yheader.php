<div id="mheader">
<img src="iterfaceimage/logoaaa.gif" width="1000" height="120" alt="logo image">
</div>
<header>
        <hgroup>
		<div>
	<ul id="nav">
	<li><a href="bayisa.php">Home</a></li>
			<li><a href="#">External User</a> 
			<ul>
			<li> <a href="#">REQUEST CREDENTIAL VERIFICATIONS</a>
			<ul>
	<li><a href="rf.php">REGISTER COMPANY<br></li></a>
				<li><a href="employeform.php">REGISTER EMPLOYEE</li></a>
			</ul></li>
			<li><a href="responsepage.php">VIEW RESPONSE</a></li>
		</ul>
			</li>
			<li><a href="rf.php">Register Company<br></li></a>
			<li><a href="employeform.php">Register Employee<br></li></a>
                        <li><a href="aboutus.php">About US</a></li>
				<li><a href="help.php">Help</a></li>
				<li><a href="TutorialHtml5EventCalendar/index.php">Calender</a></ul></div>
 </hgroup>
</header>   