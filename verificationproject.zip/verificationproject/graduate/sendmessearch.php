
<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:bayisa.php");
		   }
		   else
		   {
		   ?><html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Registerar page
</title>
</head>
<body id="contianer">
<div id="bod">
<?php
		include "registerarheader.php";
		?>
				<div id="left">
<?php
		include "registerarLeft.php";
		?>
		</div>
<div id="spacee">
<div id="aform">
<?php
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select * from company";
$r=mysql_query($q,$con);
?>
<h3>Search Graduate Information:</h3>
<form action="sendingemailstoexternal.php" method="post">
<table cellspacing="20" cellpadding="10"><br><br><br><br><br>
<tr><td><b><h2>Graduate ID:</h2></b></td><td>
<select name="Gid" id="span9001">
<?php
while($ro=mysql_fetch_array($r))
{
$qew = "select * from info_verification";
$rr=mysql_query($qew,$con);
while($row=mysql_fetch_array($rr))
{
if($row['ID']==$ro['ID'])
{
if($row['Verification']=="Verified")
{
$qstud = "select * from student";
$stud=mysql_query($qstud,$con);
while($rstud=mysql_fetch_array($stud))
{
if($row['ID']==$rstud['ID'])
{
$yu = "select * from report";
$ss=mysql_query($yu,$con);
while($roww=mysql_fetch_array($ss))
{
if($roww['ID']==$rstud['ID']) 
$yu="good";
}
if($yu!="good")
{
echo "<option>".$rstud['ID']."</option>";
}
}
}
}
}
}
}
?>
</select></td></tr>
</table>
<button class="btn btn-primary" name="search">&nbsp;Generate Report</button>
</div>
</form>
</div>
<?php
		include "yfoot.php";
		?>
</div>

</body>
<?php
}
?>

