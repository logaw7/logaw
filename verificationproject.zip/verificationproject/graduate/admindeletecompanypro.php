<html>
<head>
<title>Delete Company</title>
</head>
<body>
<?php
$Id=$_GET['ID'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
	$sql = "delete from company where company.ID='".$Id."'";
	mysql_query ($sql,$con);
	mysql_close ($con);
	echo '<script type="text/javascript">alert("Company Deleted Succesfully");window.location=\'admindeletecompany.php\';</script>';

?>
</body>
</html>