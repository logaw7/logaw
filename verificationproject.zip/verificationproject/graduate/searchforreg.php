<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:bayisa.php");
		   }
		   else
		   {
		   ?><html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Registrar Page
</title>
</head>
<body id="contianer">
<div id="bod">
<?php
		include "registerarheader.php";
		?>
						<div id="leftsh">
<?php
		include "registerarLeft.php";
		?>
		<div id="spaceesh">
<div id="aformsh">
<center><h3><p style="background-color:#FFFFFF">THE FOLLOWING ARE THE DETAILS OF GRADUATE STUDENTS AS YOU SEARCHED</p></h3></center>
<form method="post" action="viewreg.php">
<table border="4" bgcolor="#FFFFCC"sheight="10%" width="10%" class="table">
<tr class="tabl">
<th height="12%">ID</th>
<th height="12%" width="12%">FIRST_NAME</th>
<th>MIDDLE NAME</th>
<th>LAST NAME</th>
<th>GPA</th>
<th>YEAR OF GRADUATION</th>
<th>QUALIFICATION</th>
<th>GENDER</th>
<th>DEPARTMENT</th>
</tr>
<?php
		$cbo = $_POST['cbosearch'];
		$search = $_POST['search'];
		include('searchdbcon.php');
		if($cbo=="Student_ID")
		{
			$result = mysql_query("SELECT * FROM student WHERE id like '".$search."%'");
	
			while($row1=mysql_fetch_array($result))
			{
	?>
				<tr class="">
					<td class=""><?php echo $row1[0]; ?></td>
					<td><?php echo $row1[1]; ?></td>
                	<td><?php echo $row1[2]; ?></td>
                	<td><?php echo $row1[3]; ?></td>
                	<td><?php echo $row1[4]; ?></td>
                	<td><?php echo $row1[5]; ?></td>
                	<td><?php echo $row1[6]; ?></td>
                	<td><?php echo $row1[7]; ?></td>
					<td><?php echo $row1[8]; ?></td>
				
				</tr>
    <?php
			}
		}
	
		else if($cbo=="First_Name")
		{
			$result2 = mysql_query("SELECT * from student WHERE Frist_Name like '".$search."%'");
	
				while($row2=mysql_fetch_array($result2))
				{
	?>
				<tr>
					<td><?php echo $row2[0]; ?></td>
					<td><?php echo $row2[1]; ?></td>
               	 	<td><?php echo $row2[2]; ?></td>
               	 	<td><?php echo $row2[3]; ?></td>
                	<td><?php echo $row2[4]; ?></td>
                	<td><?php echo $row2[5]; ?></td>
               	 	<td><?php echo $row2[6]; ?></td>
               	 	<td><?php echo $row2[7]; ?></td>
					<td><?php echo $row2[8]; ?></td>
				
				</tr>
     <?php
				}
			  
    	 }
	 	else if($cbo=="Middle_Name")
		{
       	 	$result3 = mysql_query("SELECT * FROM student WHERE Midle_Name like '".$search."%'");
     
				while($row3=mysql_fetch_array($result3))
				{
		?>
				<tr>
					<td><?php echo $row3[0]; ?></td>
					<td><?php echo $row3[1]; ?></td>
                	<td><?php echo $row3[2]; ?></td>
                	<td><?php echo $row3[3]; ?></td>
                	<td><?php echo $row3[4]; ?></td>
                	<td><?php echo $row3[5]; ?></td>
                	<td><?php echo $row3[6]; ?></td>
                	<td><?php echo $row3[7]; ?></td>
					<td><?php echo $row3[8]; ?></td>
				
				</tr>
     <?php
				}
		}
		else if($cbo=="Last_Name")
		{
			$result4 = mysql_query("SELECT * FROM student WHERE Last_Name like '".$search."%'");
			
				while($row4=mysql_fetch_array($result4))
				{			
		?>
            	<tr>
					<td><?php echo $row4[0]; ?></td>
					<td><?php echo $row4[1]; ?></td>
                	<td><?php echo $row4[2]; ?></td>
                	<td><?php echo $row4[3]; ?></td>
                	<td><?php echo $row4[4]; ?></td>
                	<td><?php echo $row4[5]; ?></td>
                	<td><?php echo $row4[6]; ?></td>
                	<td><?php echo $row4[7]; ?></td>
					<td><?php echo $row4[8]; ?></td>

				</tr>
				<?php
				}
		}
		else if($cbo=="Cumulative_GPA")
		{
			$result5 = mysql_query("SELECT * FROM student WHERE Cumulative_Gpa like '".$search."%'");
			
				while($row5=mysql_fetch_array($result5))
				{			
		?>
            	<tr>
					<td><?php echo $row5[0]; ?></td>
					<td><?php echo $row5[1]; ?></td>
                	<td><?php echo $row5[2]; ?></td>
                	<td><?php echo $row5[3]; ?></td>
                	<td><?php echo $row5[4]; ?></td>
                	<td><?php echo $row5[5]; ?></td>
                	<td><?php echo $row5[6]; ?></td>
                	<td><?php echo $row5[7]; ?></td>
					<td><?php echo $row5[8]; ?></td>

				</tr>
				<?php
				}
		}
		else if($cbo=="Year_Of_Graduation")
		{
			$result6 = mysql_query("SELECT * FROM student WHERE Year_of_Graduation like '".$search."%'");
			
				while($row6=mysql_fetch_array($result6))
				{			
		?>
            	<tr>
					<td><?php echo $row6[0]; ?></td>
					<td><?php echo $row6[1]; ?></td>
                	<td><?php echo $row6[2]; ?></td>
                	<td><?php echo $row6[3]; ?></td>
                	<td><?php echo $row6[4]; ?></td>
                	<td><?php echo $row6[5]; ?></td>
                	<td><?php echo $row6[6]; ?></td>
                	<td><?php echo $row6[7]; ?></td>
					<td><?php echo $row6[8]; ?></td>

				</tr>
            
     <?php
				}
		}
		
		
	  ?>
 <?php 
 ?>
  
</table>
<button class="btn btn-primary"onclick="window.location.href='viewreg.php'">&nbsp;BACK TO SEARCH</button>
</div>
</form>
</div>
	</div>
<?php
		include "yfoot.php";
		?>
</div>

</body>
</html>
<?php
}
?>
