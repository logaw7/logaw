<?php
$conn = mysql_connect('localhost', 'root', '') or die(mysql_error());
$db=mysql_select_db('gcvs_db_success', $conn) or die(mysql_error($conn));
?>