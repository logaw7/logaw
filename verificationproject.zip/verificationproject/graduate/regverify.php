
<?php
            session_start();
           if(!isset($_SESSION['username']))
		   { 
		   header("location:bayisa.php");
		   }
		   else
		   {
		   ?><?php
ini_set('display_errors',1);
error_reporting(E_ALL);
?>

<html>
<head>
<link href="good.css" rel="stylesheet" type="text/css" />
<link href="admin.css" rel="stylesheet" type="text/css" />
<title>
Registerar page
</title>
</head>
<body id="contianer">
<div id="body">
<?php
		include "registerarheader.php";
		?>
				<div id="left">
<?php
		include "registerarLeft.php";
		?>
		</div>
<div id="spacee"><div id="appl">
<?php
$gid=$_POST['Gid'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select * from student WHERE ID='$gid'";
$r=mysql_query($q,$con);
?>
<?php
for ($i = 0; $i < mysql_num_rows($r); $i++)
{
$row= mysql_fetch_array($r);
?>
<h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Original Graduate Details:</h2>
<table cellspacing="15" cellpadding="10" bgcolor="#CCFFFF">
<tr><td><b>ID:</b></td><td><?php echo $row[0];?></td></tr>
<tr><td><b>First Name:</b></td><td><?php echo $row[1];?></td></tr>
<tr><td><b>Middle Name:</b></td><td><?php echo $row[2];?></td></tr>
<tr><td><b>Last Name:</b></td><td><?php echo $row[3];?></td></tr>
<tr><td><b>Year of Graduation:</b></td><td><?php echo $row[5];?></td></tr>
<tr><td><b>Quaification:</b></td><td><?php echo $row[6];?></td></tr>
<tr><td><b>Gender:</b></td><td><?php echo $row[7];?></td></tr>
<tr><td><b>Department:</b></td><td><?php echo $row[8];?></td></tr>
<tr><td><b>Photo:</b></td><td><img src="imagepro.php?ID=<?php echo $row['ID']?>" width="100" height="100"></td></tr>
<?php
}
?>
<tr><td>
<?php
if(mysql_num_rows($r)==0)
 {
 echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
 ?>
  </td> <td>
 <?php
  echo "<h2>&nbsp;&nbsp;&nbsp;Original Graduate Details:</h2>";
  ?>
  </td></tr>
 </td> <td>
 <?php
  echo "<h3><font color='red'>No Such Graduate Information!</font></h3>";
  ?>
  </td></tr>
   <?php
 }
  ?>
</table>
</div>
<?php
mysql_close($con);
?>
<div id="appr">
<?php
$gid=$_POST['Gid'];
$con = mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("gcvs_db_success", $con) or die("Can not select Database");
$q = "select * from employe WHERE ID='$gid'";
$r=mysql_query($q,$con);
if(mysql_num_rows($r)==0)
 {
 echo"No such record exists";
  exit();
 }
 ?>
<?php
for ($i = 0; $i < mysql_num_rows($r); $i++)
{
$row= mysql_fetch_row($r);
?>
<h2>&nbsp;&nbsp;&nbsp;&nbsp;Requested Graduate Details:</h2>
<form action="insertverification.php?ID=<?php echo $row[0];?>" method="post">
<table cellspacing="15" cellpadding="10" bgcolor="#FFCC99">
<tr><td><b>ID:</b></td><td><?php echo $row[0];?></td></tr>

<tr><td><b>First Name:</b></td><td><?php echo $row[1];?></td></tr>
<tr><td><b>Middle Name:</b></td><td><?php echo $row[2];?></td></tr>
<tr><td><b>Last Name:</b></td><td><?php echo $row[3];?></td></tr>
<tr><td><b>Year of Graduation:</b></td><td><?php echo $row[4];?></td></tr>
<tr><td><b>Quaification:</b></td><td><?php echo $row[5];?></td></tr>
<tr><td><b>Gender:</b></td><td><?php echo $row[6];?></td></tr>
<tr><td><b>Department:</b></td><td><?php echo $row[7];?></td></tr>
<tr><td><b>Photo:</b></td><td><img src="imagepro2.php?ID=<?php echo $row['0']?>" width="100" height="100"></td></tr></table>
<br>
<tr><td><b>Verification:</b>&nbsp;&nbsp;</td><td><select name="regA" id="span9001">
<option>--select one--</option>
<option>Verified</option>
<option>Unverified</option>
</select></td></tr><br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn btn-primary" name="regsub" value="Submit">
</form>
<?php
}
mysql_close($con);
?><br><br>
</div>
</div>

<?php
		include "yfoot.php";
		?>
</div>
</body>
</html>
<?php
}
?>